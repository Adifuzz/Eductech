package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CursoInstructorDTO;
import com.example.demo.model.Curso;
import com.example.demo.service.CursoService;

@RestController
@RequestMapping("/cursos")
@CrossOrigin (origins = "http://localhost:8080")
public class CursoControlller {
    @Autowired
    private CursoService cursoService;

    @PostMapping("/almacenar/{rut}")
    public String almacenarCurso(@PathVariable Curso curso,@PathVariable String rut){
        return cursoService.almacenarCurso(curso,rut);
    }

    @GetMapping
    public List<Curso> listarCurso(){
        return cursoService.listarCurso();
    }

    @GetMapping("/{nombreCurso}")
    public List<Curso> buscarCurso(@PathVariable String nombreCurso){
        return cursoService.buscarCurso(nombreCurso);
    }

    @PostMapping("/asignar/{sigla}/{rutInstructor}")
    public String asignarCurso(@PathVariable String sigla, @PathVariable String rutInstructor) {
        return cursoService.asignarCurso(sigla, rutInstructor);
    } 

    @PostMapping("/asignar")
    public ResponseEntity<String> asignarCurso(@RequestBody CursoInstructorDTO dto,@RequestParam String rut) {
        String resultado = cursoService.asignarCurso(dto, rut);
        return ResponseEntity.ok(resultado);
    }
    

}
