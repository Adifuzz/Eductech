package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UsuarioDTO;
//import com.example.demo.model.Persona;
import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;

@Service
public class UsuarioSrevice {
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private PerfilService perfilService;

    public String almacenarUsuario(Usuario usuario){
        if (usuario.getRut() == null || usuario.getRut().isBlank()) return "El RUT es obligatorio.";
        if (usuario.getNombre() == null || usuario.getNombre().isBlank()) return "El nombre es obligatorio.";
        if (usuario.getEmail() == null || usuario.getEmail().isBlank()) return "El email es obligatorio.";
        if (usuario.getContraseña() == null || usuario.getContraseña().isBlank()) return "La contraseña es obligatoria.";

        //Persona persona = usuario.getPersona();
        //if (persona != null) {
        //    persona.setUsuario(usuario); 
        //}

        if (usuarioRepository.existsById(usuario.getRut())) {
            return "El RUT ya está registrado.";
        }
        if (usuarioRepository.findByEmail(usuario.getEmail())!=null) {
            return "El correo ya está registrado.";
        }
        if(usuarioRepository.findByNombre(usuario.getNombre())== null){
            usuarioRepository.save(usuario);
            return "Usuario "+ usuario.getNombre()+ " almacenado correctamente";
        }else{
            return "Usuario "+usuario.getNombre()+ " ya se encuentra registrado";
        }
        
    }


    public List<UsuarioDTO> listarUsuariosDTO() {
    return usuarioRepository.findAll().stream()
        .map(usuario -> new UsuarioDTO(
            usuario.getRut(),
            usuario.getNombre(),
            usuario.getEmail(),
            usuario.getEstado(),
            usuario.getPerfiles().stream()
                .map(perfil -> perfil.getTag()) 
                .collect(Collectors.toList())
        ))
        .collect(Collectors.toList());
    }

    public List<Usuario> buscarUsuario(String nombre){
        return usuarioRepository.findByNombreContaining(nombre);
    } 

    
    public Optional<Usuario> actualizarUsuario(String rut, Usuario usuarioActualizado) {
        return usuarioRepository.findById(rut)
            .map(usuario -> {
                usuario.setNombre(usuarioActualizado.getNombre());
                usuario.setEmail(usuarioActualizado.getEmail());
                usuario.setContraseña(usuarioActualizado.getContraseña());
                if ("0".equals(usuarioActualizado.getEstado()) &&
                perfilService.tienePermiso(rut, "adminSistema")) {
                usuario.setEstado("0");
            }
                return usuarioRepository.save(usuario);
            });


    }

    
    public boolean eliminarUsuario(String rut) {
        
        if (usuarioRepository.existsById(rut)) {
            usuarioRepository.deleteById(rut);
            return true;
        }
        return false;
    }

    

}
