package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Tarjeta;
import com.example.demo.repository.TarjetaRepository;

@Service
public class TarjetaService {
    @Autowired
    private TarjetaRepository tarjetaRepository;

    public Tarjeta guardarTarjeta(Tarjeta tarjeta) {
        if (tarjeta.getNumeroTarjeta() == null || tarjeta.getNumeroTarjeta().length() < 16) {
            throw new IllegalArgumentException("El número de tarjeta debe tener al menos 16 dígitos.");
        }

        return tarjetaRepository.save(tarjeta);
    }

    

    public List<Tarjeta> obtenerTodas() {
        return tarjetaRepository.findAll();
    }

    public boolean eliminarTarjeta(String id) {
        if (tarjetaRepository.existsById(id)) {
            tarjetaRepository.deleteById(id);
            return true;
        }
        return false;
    }

}
