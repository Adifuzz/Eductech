package com.example.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Instructor {
    @Id
    private String rutInstructor;
    private String emailInstructor,contraseñaInstructor,nombreInstructor,estadoInstructor;

    @OneToMany(mappedBy = "instructor")
    @JsonBackReference 
    private List<Curso> cursos;

    @OneToMany(mappedBy = "instructor", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Mensaje> mensajes;


    public Instructor() {
        this.rutInstructor = "";
        this.emailInstructor = "";
        this.contraseñaInstructor = "";
        this.nombreInstructor = "";
        this.estadoInstructor = ""; 
    }


    public String getRutInstructor() {
        return rutInstructor;
    }


    public void setRutInstructor(String rutInstructor) {
        this.rutInstructor = rutInstructor;
    }


    public String getEmailInstructor() {
        return emailInstructor;
    }


    public void setEmailInstructor(String emailInstructor) {
        this.emailInstructor = emailInstructor;
    }


    public String getContraseñaInstructor() {
        return contraseñaInstructor;
    }


    public void setContraseñaInstructor(String contraseñaInstructor) {
        this.contraseñaInstructor = contraseñaInstructor;
    }


    public String getNombreInstructor() {
        return nombreInstructor;
    }


    public void setNombreInstructor(String nombreInstructor) {
        this.nombreInstructor = nombreInstructor;
    }


    public String getEstadoInstructor() {
        return estadoInstructor;
    }


    public void setEstadoInstructor(String estadoInstructor) {
        this.estadoInstructor = estadoInstructor;
    }


    public List<Curso> getCursos() {
        return cursos;
    }


    public void setCursos(List<Curso> cursos) {
        this.cursos = cursos;
    }


    public List<Mensaje> getMensajes() {
        return mensajes;
    }


    public void setMensajes(List<Mensaje> mensajes) {
        this.mensajes = mensajes;
    } 
    

    

    

    

    

    

}
