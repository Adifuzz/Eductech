package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CuponPago {
    @Id
    private int codigoCupon;
    private int porcentajeDescuanto;

    public CuponPago() {
        this.codigoCupon = 0;
        this.porcentajeDescuanto = 0;
    }

    public int getCodigoCupon() {
        return codigoCupon;
    }

    public void setCodigoCupon(int codigoCupon) {
        this.codigoCupon = codigoCupon;
    }

    public int getPorcentajeDescuanto() {
        return porcentajeDescuanto;
    }

    public void setPorcentajeDescuanto(int porcentajeDescuanto) {
        this.porcentajeDescuanto = porcentajeDescuanto;
    } 

    

    

}
