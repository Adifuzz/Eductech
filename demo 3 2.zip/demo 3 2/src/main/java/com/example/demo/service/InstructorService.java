package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.model.Instructor;
import com.example.demo.model.Mensaje;
import com.example.demo.repository.InstructorRepository;

@Service
public class InstructorService {
    @Autowired
    private InstructorRepository instructorRepository;
   

    public String almacenarInstructor(Instructor instructor){
        if(instructorRepository.findByNombreInstructor(instructor.getNombreInstructor())== null){
            instructorRepository.save(instructor);
            return "Instructor "+ instructor.getNombreInstructor()+ " almacenado correctamente";
        }else{
            return "Instructor "+instructor.getNombreInstructor()+ " ya se encuentra registrado";
        }
    }


    public List<Instructor> listarInstructor(){
        return instructorRepository.findAll();
    }

    public List<Instructor> buscarInstructor(String nombreInstructor){
        return instructorRepository.findByNombreInstructorContaining(nombreInstructor);
    } 

    public List<Mensaje> obtenerMensajesPorInstructor(String rut) {
        Instructor instructor = instructorRepository.findById(rut).orElse(null);
        return instructor != null ? instructor.getMensajes() : null;
    }

    

}

