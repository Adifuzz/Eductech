package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Persona;
import com.example.demo.service.PersonaService;


@RestController
@RequestMapping("/personas")
@CrossOrigin (origins = "http://localhost:8080")
public class PersonaController {
    @Autowired
    private PersonaService personaService;

    
    @GetMapping
    public List<Persona> obtenerTodasLasPersonas() {
        return personaService.listarPersonas();
    }

   
    public ResponseEntity<Persona> obtenerPersona(@PathVariable String rutPersona) {
        Persona persona = personaService.obtenerPersona(rutPersona);
        if (persona != null) {
            return ResponseEntity.ok(persona);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // POST: crear una nueva persona
    @PostMapping
    public ResponseEntity<Persona> crearPersona(@RequestBody Persona persona) {
        Persona personaGuardada = personaService.guardarPersona(persona);
        return ResponseEntity.ok(personaGuardada);
    }

    
    @PutMapping("/{id}")
    public ResponseEntity<Persona> actualizarPersona(@PathVariable int id, @RequestBody Persona persona) {
        persona.setIdPersona(id);
        Persona actualizada = personaService.actualizarPersona(persona);
        if (actualizada != null) {
            return ResponseEntity.ok(actualizada);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE: eliminar persona por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminarPersona(@PathVariable int id) {
        boolean eliminada = personaService.eliminarPersona(id);
        if (eliminada) {
            return ResponseEntity.ok("Persona eliminada correctamente.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
