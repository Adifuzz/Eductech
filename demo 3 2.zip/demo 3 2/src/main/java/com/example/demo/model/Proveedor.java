package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Proveedor {
    @Id
    private String rutProveedor;
    private String nombreProveedor,descripcionProveedor,email;


    public Proveedor() {
        this.rutProveedor = "";
        this.nombreProveedor = "";
        this.descripcionProveedor = "";
        this.email = "";
    }


    public String getRutProveedor() {
        return rutProveedor;
    }


    public void setRutProveedor(String rutProveedor) {
        this.rutProveedor = rutProveedor;
    }


    public String getNombreProveedor() {
        return nombreProveedor;
    }


    public void setNombreProveedor(String nombreProveedor) {
        this.nombreProveedor = nombreProveedor;
    }


    public String getDescripcionProveedor() {
        return descripcionProveedor;
    }


    public void setDescripcionProveedor(String descripcionProveedor) {
        this.descripcionProveedor = descripcionProveedor;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    } 

    

    
    


}
