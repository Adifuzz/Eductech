package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Perfil {
    @Id
    private String tag;
    private boolean adminSistema;
    private boolean adminCurso;
    private boolean alumno;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "usuario_perfil")
    private Usuario usuario;

    public Perfil() {
        this.tag = "";
        this.adminSistema = false;
        this.adminCurso = false;
        this.alumno = false;
    }

   

    public boolean isAdminSistema() {
        return adminSistema;
    }

    public void setAdminSistema(boolean adminSistema) {
        this.adminSistema = adminSistema;
    }

    public boolean isAdminCurso() {
        return adminCurso;
    }

    public void setAdminCurso(boolean adminCurso) {
        this.adminCurso = adminCurso;
    }

    



    public String getTag() {
        return tag;
    }



    public void setTag(String tag) {
        this.tag = tag;
    }



    public Usuario getUsuario() {
        return usuario;
    }



    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }



    public boolean isAlumno() {
        return alumno;
    }



    public void setAlumno(boolean alumno) {
        this.alumno = alumno;
    }



    

    

    

    


    
    

    

    
}
