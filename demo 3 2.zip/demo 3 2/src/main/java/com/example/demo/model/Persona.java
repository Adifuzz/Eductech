package com.example.demo.model;




import java.util.HashSet;
import java.util.Set;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class Persona{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPersona;
    private String rutPersona;
    private String emailPersona, nombrePersona,direccion,telefono,ocupacion;

    @OneToMany(mappedBy = "persona")
    private Set<Usuario> usuarios = new HashSet<>();
    @OneToMany(mappedBy = "persona")
    private Set<Tarjeta> tarjetas = new HashSet<>();



    public Persona() {
        this.rutPersona = "";
        this.emailPersona = "";
        this.nombrePersona = "";
        this.direccion = "";
        this.telefono = "";
        this.ocupacion = "";
    }


    public String getRutPersona() {
        return rutPersona;
    }


    public void setRutPersona(String rutPersona) {
        this.rutPersona = rutPersona;
    }


    public String getEmailPersona() {
        return emailPersona;
    }


    public void setEmailPersona(String emailPersona) {
        this.emailPersona = emailPersona;
    }


    public String getNombrePersona() {
        return nombrePersona;
    }


    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }


    public String getDireccion() {
        return direccion;
    }


    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }


    public String getTelefono() {
        return telefono;
    }


    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


    public String getOcuapacion() {
        return ocupacion;
    }


    public void setOcuapacion(String ocuapacion) {
        this.ocupacion = ocuapacion;
    }


    public int getIdPersona() {
        return idPersona;
    }


    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }


    public String getOcupacion() {
        return ocupacion;
    }


    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }


    public Set<Usuario> getUsuarios() {
        return usuarios;
    }


    public void setUsuarios(Set<Usuario> usuarios) {
        this.usuarios = usuarios;
    }


    public Set<Tarjeta> getTarjetas() {
        return tarjetas;
    }


    public void setTarjetas(Set<Tarjeta> tarjetas) {
        this.tarjetas = tarjetas;
    }


    

    

    
    
    
    

    

    
    

    

    
}
