package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Resenia {
    @Id
    private int idResenia;
    private String descripcion,fecha;


    public Resenia() {
        this.idResenia = 0;
        this.descripcion = "";
        this.fecha = "";
    }


    public int getIdResenia() {
        return idResenia;
    }


    public void setIdResenia(int idResenia) {
        this.idResenia = idResenia;
    }


    public String getDescripcion() {
        return descripcion;
    }


    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }


    public String getFecha() {
        return fecha;
    }


    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    

    
    

}
