package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Mensaje;
import com.example.demo.service.MensajeService;

@RestController
@RequestMapping("Mensajes")
@CrossOrigin (origins = "http://localhost:8080")
public class MensajeController {

    @Autowired
    private MensajeService mensajeService;

    @PostMapping("/crear")
    public Mensaje enviarMensaje(@RequestBody Mensaje mensaje) {
        return mensajeService.guardarMensaje(mensaje);
    }

    @GetMapping("/curso/{cursoSigla}")
    public List<Mensaje> verMensajesCurso(@PathVariable String cursoSigla) {
        return mensajeService.obtenerMensajesPorCurso(cursoSigla);
    }
}
