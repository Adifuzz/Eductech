package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Incidencia {
    @Id
    private int idIncidencia;
    private String descripcionIncidencia,email,estadoIncidencia;


    public Incidencia() {
        this.idIncidencia = 0;
        this.descripcionIncidencia = "";
        this.email = "";
        this.estadoIncidencia = ""; 
    }


    public int getIdIncidencia() {
        return idIncidencia;
    }


    public void setIdIncidencia(int idIncidencia) {
        this.idIncidencia = idIncidencia;
    }


    public String getDescripcionIncidencia() {
        return descripcionIncidencia;
    }


    public void setDescripcionIncidencia(String descripcionIncidencia) {
        this.descripcionIncidencia = descripcionIncidencia;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    public String getEstadoIncidencia() {
        return estadoIncidencia;
    }


    public void setEstadoIncidencia(String estadoIncidencia) {
        this.estadoIncidencia = estadoIncidencia;
    } 

    

    


}
