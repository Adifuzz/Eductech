package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.model.Evaluacion;
import com.example.demo.repository.EvaluacionRepository;

@Service
public class EvaluacionService {

    private final EvaluacionRepository evaluacionRepository;

    public EvaluacionService(EvaluacionRepository evaluacionRepository) {
        this.evaluacionRepository = evaluacionRepository;
    }

    public Evaluacion crearEvaluacion(Evaluacion evaluacion) {
        return evaluacionRepository.save(evaluacion);
    }

    public Optional<Evaluacion> obtenerEvaluacionPorId(int id) {
        return evaluacionRepository.findById(id);
    }

    public List<Evaluacion> listarEvaluaciones() {
        return evaluacionRepository.findAll();
    }

    public void eliminarEvaluacion(int id) {
        evaluacionRepository.deleteById(id);
    }

    public Evaluacion actualizarEvaluacion(int id, Evaluacion nuevaEvaluacion) {
        return evaluacionRepository.findById(id).map(e -> {
            e.setNombre(nuevaEvaluacion.getNombre());
            return evaluacionRepository.save(e);
        }).orElseGet(() -> {
            nuevaEvaluacion.setIdEvalucion(id);
            return evaluacionRepository.save(nuevaEvaluacion);
        });
    }
}
