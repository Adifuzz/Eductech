package com.example.demo.model;

import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Tarjeta {
    @Id
    private String numeroTarjeta;
    private String titular;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "persona_Tarjeta")
    private Persona persona;
    @OneToMany(mappedBy = "tarjeta")
    private Set<FormaPago> pagos = new HashSet<>();

    public Tarjeta() {
        this.numeroTarjeta = "";
        this.titular = "";
    }

    

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }



    


    public Persona getPersona() {
        return persona;
    }



    public void setPersona(Persona persona) {
        this.persona = persona;
    }



    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }



    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }



    public Set<FormaPago> getPagos() {
        return pagos;
    }



    public void setPagos(Set<FormaPago> pagos) {
        this.pagos = pagos;
    }



    
    
    

    


}

