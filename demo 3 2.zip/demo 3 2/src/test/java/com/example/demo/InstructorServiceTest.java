package com.example.demo;

import com.example.demo.model.Instructor;
import com.example.demo.model.Mensaje;
import com.example.demo.repository.InstructorRepository;
import com.example.demo.service.InstructorService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InstructorServiceTest {

    @Mock
    private InstructorRepository instructorRepository;

    @InjectMocks
    private InstructorService instructorService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    //STANLEY
    @Test   
    void testAlmacenarInstructor_NuevoInstructor() {
    Instructor instructor = new Instructor();
    instructor.setRutInstructor("123");
    instructor.setNombreInstructor("Juan");

    
    when(instructorRepository.findByNombreInstructor("Juan")).thenReturn(null);
    when(instructorRepository.save(instructor)).thenReturn(instructor);

    String resultado = instructorService.almacenarInstructor(instructor);

    assertEquals("Instructor Juan almacenado correctamente", resultado);
    verify(instructorRepository, times(1)).save(instructor);
    }

    @Test
    void testObtenerMensajesPorInstructor_Encontrado() {
        Instructor instructor = new Instructor();
        instructor.setRutInstructor("123");

        Mensaje msg1 = new Mensaje();
        Mensaje msg2 = new Mensaje();
        List<Mensaje> mensajes = Arrays.asList(msg1, msg2);
        instructor.setMensajes(mensajes);

        when(instructorRepository.findById("123")).thenReturn(Optional.of(instructor));

        List<Mensaje> resultado = instructorService.obtenerMensajesPorInstructor("123");

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(instructorRepository, times(1)).findById("123");
    }

    @Test
    void testObtenerMensajesPorInstructor_NoEncontrado() {
        when(instructorRepository.findById("999")).thenReturn(Optional.empty());

        List<Mensaje> resultado = instructorService.obtenerMensajesPorInstructor("999");

        assertNull(resultado);
        verify(instructorRepository, times(1)).findById("999");
    }
}