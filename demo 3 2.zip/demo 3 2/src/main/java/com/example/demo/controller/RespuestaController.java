package com.example.demo.controller;

import com.example.demo.model.Respuesta;
import com.example.demo.service.RepuestaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/respuestas")
public class RespuestaController {

    @Autowired
    private RepuestaService repuestaService;

    @GetMapping
    public List<Respuesta> getAllRepuestas() {
        return repuestaService.getAllRepuestas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Respuesta> getRepuestaById(@PathVariable int id) {
        return repuestaService.getRepuestaById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Respuesta createRepuesta(@RequestBody Respuesta repuesta) {
        return repuestaService.createRepuesta(repuesta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Respuesta> updateRepuesta(@PathVariable int id, @RequestBody Respuesta updatedRepuesta) {
        Respuesta repuesta = repuestaService.updateRepuesta(id, updatedRepuesta);
        return (repuesta != null) ? ResponseEntity.ok(repuesta) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRepuesta(@PathVariable int id) {
        return repuestaService.deleteRepuesta(id) ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
