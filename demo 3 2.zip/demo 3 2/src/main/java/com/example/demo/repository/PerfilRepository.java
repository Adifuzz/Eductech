package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.demo.model.Perfil;

public interface PerfilRepository extends JpaRepository <Perfil,String>{
    Perfil findByTag(String tag);

    List<Perfil>findBytagContaining(String tag);

}
