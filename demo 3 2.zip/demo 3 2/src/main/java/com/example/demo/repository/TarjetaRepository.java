package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Tarjeta;

public interface TarjetaRepository extends JpaRepository<Tarjeta,String>{
    

}
