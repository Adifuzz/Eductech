package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Persona;
import com.example.demo.repository.PersonaRepository;

@Service
public class PersonaService {
    @Autowired
    private PersonaRepository personaRepository;

    public Persona guardarPersona(Persona persona) {
        return personaRepository.save(persona);
    }

    public Persona obtenerPersona(String rutPersona) {
        return personaRepository.findByRutPersona(rutPersona);
    }

    public List<Persona> listarPersonas() {
        return personaRepository.findAll();
    }

    public boolean eliminarPersona(int id) {
        if (personaRepository.existsById(id)) {
            personaRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public Persona actualizarPersona(Persona persona) {
        if (personaRepository.existsById(persona.getIdPersona())) {
            return personaRepository.save(persona);
        }
        return null;
    }
}
