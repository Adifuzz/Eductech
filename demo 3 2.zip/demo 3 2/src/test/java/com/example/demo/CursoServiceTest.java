package com.example.demo;



import com.example.demo.dto.CursoInstructorDTO;
import com.example.demo.model.Curso;
import com.example.demo.model.Instructor;
import com.example.demo.repository.CursoRepository;
import com.example.demo.repository.InstructorRepository;
import com.example.demo.service.CursoService;
import com.example.demo.service.PerfilService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CursoServiceTest {

    @Mock
    private CursoRepository cursoRepository;

    @Mock
    private InstructorRepository instructorRepository;

    @Mock
    private PerfilService perfilService;

    @InjectMocks
    private CursoService cursoService;

    private Curso curso;
    private Instructor instructor;
    private CursoInstructorDTO dto;

    @BeforeEach
    void setUp() {
        curso = new Curso();
        curso.setSigla("MA1");
        curso.setNombreCurso("Matemáticas");

        instructor = new Instructor();
        instructor.setRutInstructor("12345678-9");
        instructor.setNombreInstructor("Juan Pérez");

        dto = new CursoInstructorDTO();
        dto.setSigla("MA1");
        dto.setRutInstructor("12345678-9");
    }
    //ADOLFO
    @Test
    void testAlmacenarCurso_Success() {
        Curso curso = new Curso();
        curso.setSigla("MA");
        
        when(perfilService.tienePermiso("123", "adminCurso")).thenReturn(true);
        when(cursoRepository.findBySiglaStartingWith("MA")).thenReturn(Collections.emptyList());
        when(cursoRepository.save(curso)).thenReturn(curso);

        String resultado = cursoService.almacenarCurso(curso, "123");

        assertEquals("Curso almacenado con sigla: MA1", resultado);
        verify(cursoRepository, times(1)).save(curso);
    }

    @Test
    void testAlmacenarCurso_NoPermission() {
        when(perfilService.tienePermiso(anyString(), eq("adminCurso"))).thenReturn(false);

        String result = cursoService.almacenarCurso(curso, "user-rut");

        assertEquals("Error: No tienes permiso para crear curso.", result);
        verify(cursoRepository, never()).save(any(Curso.class));
    }

    @Test
    void testListarCurso() {
        List<Curso> cursos = Arrays.asList(curso);
        when(cursoRepository.findAll()).thenReturn(cursos);

        List<Curso> result = cursoService.listarCurso();

        assertEquals(1, result.size());
        assertEquals("Matemáticas", result.get(0).getNombreCurso());
        verify(cursoRepository, times(1)).findAll();
    }

    @Test
    void testBuscarCurso() {
        List<Curso> cursos = Arrays.asList(curso);
        when(cursoRepository.findByNombreCursoContaining(anyString())).thenReturn(cursos);

        List<Curso> result = cursoService.buscarCurso("Mat");

        assertEquals(1, result.size());
        assertEquals("Matemáticas", result.get(0).getNombreCurso());
        verify(cursoRepository, times(1)).findByNombreCursoContaining("Mat");
    }

    @Test
    void testAsignarCurso_Success() {
        when(cursoRepository.existsById("MA1")).thenReturn(true);
        when(instructorRepository.existsById("12345678-9")).thenReturn(true);
        when(cursoRepository.findById("MA1")).thenReturn(Optional.of(curso));
        when(instructorRepository.findById("12345678-9")).thenReturn(Optional.of(instructor));

        String result = cursoService.asignarCurso("MA1", "12345678-9");

        assertEquals("Curso Matemáticas asiganado a instructor Juan Pérez correctamente", result);
        verify(cursoRepository, times(1)).save(curso);
    }

    @Test
    void testAsignarCurso_CursoNotFound() {
        when(cursoRepository.existsById("MA1")).thenReturn(false);

        String result = cursoService.asignarCurso("MA1", "12345678-9");

        assertEquals("El curso ingresado no existe", result);
        verify(cursoRepository, never()).save(any());
    }

    @Test
    void testAsignarCurso_InstructorNotFound() {
        when(cursoRepository.existsById("MA1")).thenReturn(true);
        when(instructorRepository.existsById("12345678-9")).thenReturn(false);

        String result = cursoService.asignarCurso("MA1", "12345678-9");

        assertEquals("El instructor no esta registrado", result);
        verify(cursoRepository, never()).save(any());
    }

    @Test
    void testAsignarCursoWithDTO_Success() {
        when(perfilService.tienePermiso(anyString(), eq("adminCurso"))).thenReturn(true);
        when(cursoRepository.existsById("MA1")).thenReturn(true);
        when(instructorRepository.existsById("12345678-9")).thenReturn(true);
        when(cursoRepository.findById("MA1")).thenReturn(Optional.of(curso));
        when(instructorRepository.findById("12345678-9")).thenReturn(Optional.of(instructor));

        String result = cursoService.asignarCurso(dto, "admin-rut");

        assertEquals("Curso Matemáticas asiganado a instructor Juan Pérez correctamente", result);
        verify(cursoRepository, times(1)).save(curso);
    }

    @Test
    void testAsignarCursoWithDTO_NoPermission() {
        when(perfilService.tienePermiso(anyString(), eq("adminCurso"))).thenReturn(false);

        String result = cursoService.asignarCurso(dto, "user-rut");

        assertEquals("Error: No tienes permiso para asignar cursos.", result);
        verify(cursoRepository, never()).save(any());
    }
    //ADOLFO
    @Test
    void testGenerarSigla() {
        when(cursoRepository.findBySiglaStartingWith("MA")).thenReturn(Arrays.asList(curso));

        String sigla = cursoService.generarSigla("Matemáticas");

        assertEquals("MA2", sigla); 
        verify(cursoRepository, times(1)).findBySiglaStartingWith("MA");
    }

    @Test
    void testGenerarSigla_FirstCourse() {
        when(cursoRepository.findBySiglaStartingWith("MA")).thenReturn(Collections.emptyList());

        String sigla = cursoService.generarSigla("Matemáticas");

        assertEquals("MA1", sigla);
        verify(cursoRepository, times(1)).findBySiglaStartingWith("MA");
    }
}
