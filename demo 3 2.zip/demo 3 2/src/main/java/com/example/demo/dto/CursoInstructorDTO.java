package com.example.demo.dto;

public class CursoInstructorDTO {
    private String rutInstructor;
    private String nombreInstructor;
    private String emailInstructor;
    private String sigla;

    public CursoInstructorDTO() {
        this.rutInstructor = "";
        this.nombreInstructor = "";
        this.emailInstructor = "";
        this.sigla = ""; 
    }

    public CursoInstructorDTO(String rutInstructor, String nombreInstructor, String emailInstructor, String sigla) {
        this.rutInstructor = rutInstructor;
        this.nombreInstructor = nombreInstructor;
        this.emailInstructor = emailInstructor;
        this.sigla = sigla;
    }

    public String getRutInstructor() {
        return rutInstructor;
    }

    public void setRutInstructor(String rutInstructor) {
        this.rutInstructor = rutInstructor;
    }

    public String getNombreInstructor() {
        return nombreInstructor;
    }

    public void setNombreInstructor(String nombreInstructor) {
        this.nombreInstructor = nombreInstructor;
    }

    public String getEmailInstructor() {
        return emailInstructor;
    }

    public void setEmailInstructor(String emailInstructor) {
        this.emailInstructor = emailInstructor;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    


    

    

    
}
