package com.example.demo;

import com.example.demo.dto.UsuarioDTO;
import com.example.demo.model.Usuario;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.PerfilService;
import com.example.demo.service.UsuarioSrevice;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

//import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private PerfilService perfilService;

    @InjectMocks
    private UsuarioSrevice usuarioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAlmacenarUsuario_Success() {
        Usuario usuario = new Usuario();
        usuario.setRut("12345678-9");
        usuario.setNombre("Juan Perez");
        usuario.setEmail("juan@example.com");
        usuario.setContraseña("password123");

        when(usuarioRepository.existsById("12345678-9")).thenReturn(false);
        when(usuarioRepository.findByEmail("juan@example.com")).thenReturn(null);
        when(usuarioRepository.findByNombre("Juan Perez")).thenReturn(null);
        when(usuarioRepository.save(usuario)).thenReturn(usuario);

        String resultado = usuarioService.almacenarUsuario(usuario);

        assertEquals("Usuario Juan Perez almacenado correctamente", resultado);
        verify(usuarioRepository, times(1)).save(usuario);
    }
    //STANLEY
    @Test
    void testAlmacenarUsuario_RutObligatorio() {
        Usuario usuario = new Usuario();
        usuario.setRut(null);
        usuario.setNombre("Juan Perez");
        usuario.setEmail("juan@example.com");
        usuario.setContraseña("password123");

        String resultado = usuarioService.almacenarUsuario(usuario);

        assertEquals("El RUT es obligatorio.", resultado);
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void testAlmacenarUsuario_RutExistente() {
        Usuario usuario = new Usuario();
        usuario.setRut("12345678-9");
        usuario.setNombre("Juan Perez");
        usuario.setEmail("juan@example.com");
        usuario.setContraseña("password123");

        when(usuarioRepository.existsById("12345678-9")).thenReturn(true);

        String resultado = usuarioService.almacenarUsuario(usuario);

        assertEquals("El RUT ya está registrado.", resultado);
        verify(usuarioRepository, never()).save(any());
    }
    //ADOLFO
    @Test
    void testAlmacenarUsuario_EmailExistente() {
        Usuario usuario = new Usuario();
        usuario.setRut("12345678-9");
        usuario.setNombre("Juan Perez");
        usuario.setEmail("juan@example.com");
        usuario.setContraseña("password123");

        when(usuarioRepository.existsById("12345678-9")).thenReturn(false);
        when(usuarioRepository.findByEmail("juan@example.com")).thenReturn(new Usuario());

        String resultado = usuarioService.almacenarUsuario(usuario);

        assertEquals("El correo ya está registrado.", resultado);
        verify(usuarioRepository, never()).save(any());
    }
    //ADOLFO
    @Test
    void testListarUsuariosDTO() {
        Usuario usuario = new Usuario();
        usuario.setRut("12345678-9");
        usuario.setNombre("Juan Perez");
        usuario.setEmail("juan@example.com");
        usuario.setEstado("1");

        when(usuarioRepository.findAll()).thenReturn(Collections.singletonList(usuario));

        List<UsuarioDTO> resultado = usuarioService.listarUsuariosDTO();

        assertEquals(1, resultado.size());
        assertEquals("12345678-9", resultado.get(0).getRut());
        verify(usuarioRepository, times(1)).findAll();
    }

    

    @Test
    void testActualizarUsuario_Success() {
        Usuario usuarioExistente = new Usuario();
        usuarioExistente.setRut("12345678-9");
        usuarioExistente.setNombre("Juan Perez");
        usuarioExistente.setEmail("juan@example.com");
        usuarioExistente.setContraseña("oldpassword");

        Usuario usuarioActualizado = new Usuario();
        usuarioActualizado.setNombre("Juan Carlos Perez");
        usuarioActualizado.setEmail("juan.carlos@example.com");
        usuarioActualizado.setContraseña("newpassword");

        when(usuarioRepository.findById("12345678-9")).thenReturn(Optional.of(usuarioExistente));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuarioExistente);

        Optional<Usuario> resultado = usuarioService.actualizarUsuario("12345678-9", usuarioActualizado);

        assertTrue(resultado.isPresent());
        assertEquals("Juan Carlos Perez", resultado.get().getNombre());
        verify(usuarioRepository, times(1)).save(usuarioExistente);
    }

    @Test
    void testActualizarUsuario_AdminSistema() {
        Usuario usuarioExistente = new Usuario();
        usuarioExistente.setRut("12345678-9");
        usuarioExistente.setEstado("1");

        Usuario usuarioActualizado = new Usuario();
        usuarioActualizado.setEstado("0");

        when(usuarioRepository.findById("12345678-9")).thenReturn(Optional.of(usuarioExistente));
        when(perfilService.tienePermiso("12345678-9", "adminSistema")).thenReturn(true);
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuarioExistente);

        Optional<Usuario> resultado = usuarioService.actualizarUsuario("12345678-9", usuarioActualizado);

        assertTrue(resultado.isPresent());
        assertEquals("0", resultado.get().getEstado());
    }

    @Test
    void testActualizarUsuario_NotFound() {
        when(usuarioRepository.findById("99999999-9")).thenReturn(Optional.empty());

        Optional<Usuario> resultado = usuarioService.actualizarUsuario("99999999-9", new Usuario());

        assertFalse(resultado.isPresent());
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    void testEliminarUsuario_Success() {
        when(usuarioRepository.existsById("12345678-9")).thenReturn(true);
        doNothing().when(usuarioRepository).deleteById("12345678-9");

        boolean resultado = usuarioService.eliminarUsuario("12345678-9");

        assertTrue(resultado);
        verify(usuarioRepository, times(1)).deleteById("12345678-9");
    }

    @Test
    void testEliminarUsuario_NotFound() {
        when(usuarioRepository.existsById("99999999-9")).thenReturn(false);

        boolean resultado = usuarioService.eliminarUsuario("99999999-9");

        assertFalse(resultado);
        verify(usuarioRepository, never()).deleteById(anyString());
    }
}
