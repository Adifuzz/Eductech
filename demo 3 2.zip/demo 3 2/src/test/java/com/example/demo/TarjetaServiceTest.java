package com.example.demo;

import com.example.demo.model.Tarjeta;
import com.example.demo.repository.TarjetaRepository;
import com.example.demo.service.TarjetaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
//import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TarjetaServiceTest {

    @Mock
    private TarjetaRepository tarjetaRepository;

    @InjectMocks
    private TarjetaService tarjetaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGuardarTarjeta_Success() {
        Tarjeta tarjeta = new Tarjeta();
        tarjeta.setNumeroTarjeta("1234567890123456"); // 16 dígitos
        
        when(tarjetaRepository.save(tarjeta)).thenReturn(tarjeta);

        Tarjeta resultado = tarjetaService.guardarTarjeta(tarjeta);

        assertNotNull(resultado);
        assertEquals("1234567890123456", resultado.getNumeroTarjeta());
        verify(tarjetaRepository, times(1)).save(tarjeta);
    }
    //ADOLFO
    @Test
    void testGuardarTarjeta_NumeroInvalido() {
        Tarjeta tarjeta = new Tarjeta();
        tarjeta.setNumeroTarjeta("123"); // Menos de 16 dígitos

        assertThrows(IllegalArgumentException.class, () -> {
            tarjetaService.guardarTarjeta(tarjeta);
        });

        verify(tarjetaRepository, never()).save(any());
    }

    @Test
    void testObtenerTodas() {
        Tarjeta tarjeta1 = new Tarjeta();
        Tarjeta tarjeta2 = new Tarjeta();
        List<Tarjeta> tarjetas = Arrays.asList(tarjeta1, tarjeta2);

        when(tarjetaRepository.findAll()).thenReturn(tarjetas);

        List<Tarjeta> resultado = tarjetaService.obtenerTodas();

        assertEquals(2, resultado.size());
        verify(tarjetaRepository, times(1)).findAll();
    }

    @Test
    void testEliminarTarjeta_Existente() {
        String id = "TARJ-123";
        when(tarjetaRepository.existsById(id)).thenReturn(true);
        doNothing().when(tarjetaRepository).deleteById(id);

        boolean resultado = tarjetaService.eliminarTarjeta(id);

        assertTrue(resultado);
        verify(tarjetaRepository, times(1)).deleteById(id);
    }

    @Test
    void testEliminarTarjeta_NoExistente() {
        String id = "TARJ-999";
        when(tarjetaRepository.existsById(id)).thenReturn(false);

        boolean resultado = tarjetaService.eliminarTarjeta(id);

        assertFalse(resultado);
        verify(tarjetaRepository, never()).deleteById(anyString());
    }
}
