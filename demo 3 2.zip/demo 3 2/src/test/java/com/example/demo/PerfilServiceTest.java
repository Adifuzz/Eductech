package com.example.demo;

import com.example.demo.dto.PerfilUsuarioDTO;
import com.example.demo.model.Perfil;
import com.example.demo.model.Usuario;
import com.example.demo.repository.PerfilRepository;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.PerfilService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

//import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PerfilServiceTest {

    @Mock
    private PerfilRepository perfilRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private PerfilService perfilService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAsignarPerfil_Success() {
        PerfilUsuarioDTO dto = new PerfilUsuarioDTO();
        dto.setTag("ADMIN");
        dto.setRut("123");

        Perfil perfil = new Perfil();
        perfil.setTag("ADMIN");

        Usuario usuario = new Usuario();
        usuario.setRut("123");
        usuario.setNombre("Juan");

        when(perfilRepository.existsById("ADMIN")).thenReturn(true);
        when(usuarioRepository.existsById("123")).thenReturn(true);
        when(perfilRepository.findById("ADMIN")).thenReturn(Optional.of(perfil));
        when(usuarioRepository.findById("123")).thenReturn(Optional.of(usuario));

        String resultado = perfilService.asignarPerfil(dto);

        assertEquals("Perfil ADMIN asiganado a Usuario Juan correctamente", resultado);
        verify(perfilRepository, times(1)).save(perfil);
    }

    @Test
    void testAsignarPerfil_PerfilNoExiste() {
        PerfilUsuarioDTO dto = new PerfilUsuarioDTO();
        dto.setTag("ADMIN");
        dto.setRut("123");

        when(perfilRepository.existsById("ADMIN")).thenReturn(false);

        String resultado = perfilService.asignarPerfil(dto);

        assertEquals("El perfilingresado no existe", resultado);
        verify(perfilRepository, never()).save(any());
    }

    @Test
    void testObtenerPerfilesDeUsuario_Encontrado() {
        Usuario usuario = new Usuario();
        usuario.setRut("123");
        Perfil perfil = new Perfil();
        usuario.setPerfiles(Set.of(perfil));

        when(usuarioRepository.findById("123")).thenReturn(Optional.of(usuario));

        Set<Perfil> resultado = perfilService.obtenerPerfilesDeUsuario("123");

        assertEquals(1, resultado.size());
        verify(usuarioRepository, times(1)).findById("123");
    }

    @Test
    void testObtenerPerfilesDeUsuario_NoEncontrado() {
        when(usuarioRepository.findById("999")).thenReturn(Optional.empty());

        Set<Perfil> resultado = perfilService.obtenerPerfilesDeUsuario("999");

        assertTrue(resultado.isEmpty());
        verify(usuarioRepository, times(1)).findById("999");
    }

    @Test
    void testTienePermiso_AdminSistema() {
        Usuario usuario = new Usuario();
        Perfil perfil = new Perfil();
        perfil.setAdminSistema(true);
        usuario.setPerfiles(Set.of(perfil));

        when(usuarioRepository.findById("123")).thenReturn(Optional.of(usuario));

        boolean resultado = perfilService.tienePermiso("123", "adminSistema");

        assertTrue(resultado);
    }
    //ADOLFO
    @Test
    void testTienePermiso_SinPermiso() {
        Usuario usuario = new Usuario();
        Perfil perfil = new Perfil();
        perfil.setAdminSistema(false);
        usuario.setPerfiles(Set.of(perfil));

        when(usuarioRepository.findById("123")).thenReturn(Optional.of(usuario));

        boolean resultado = perfilService.tienePermiso("123", "adminSistema");

        assertFalse(resultado);
    }

    @Test
    void testListarPerfi() {
        Perfil perfil = new Perfil();
        when(perfilRepository.findAll()).thenReturn(List.of(perfil));

        List<Perfil> resultado = perfilService.listarPerfi();

        assertEquals(1, resultado.size());
        verify(perfilRepository, times(1)).findAll();
    }

    @Test
    void testAlmacenarPerfil_Nuevo() {
        Perfil perfil = new Perfil();
        perfil.setTag("NEW");

        when(perfilRepository.existsById("NEW")).thenReturn(false);
        when(perfilRepository.save(perfil)).thenReturn(perfil);

        String resultado = perfilService.almacenarPerfil(perfil);

        assertEquals("Perfil NEW almacenado correctamente", resultado);
        verify(perfilRepository, times(1)).save(perfil);
    }

    @Test
    void testAlmacenarPerfil_Existente() {
        Perfil perfil = new Perfil();
        perfil.setTag("EXIST");

        when(perfilRepository.existsById("EXIST")).thenReturn(true);

        String resultado = perfilService.almacenarPerfil(perfil);

        assertEquals("Perfil EXIST ya se encuentra registrado", resultado);
        verify(perfilRepository, never()).save(any());
    }
}
