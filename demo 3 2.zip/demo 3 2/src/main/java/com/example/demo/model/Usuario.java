package com.example.demo.model;


import java.util.HashSet;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;


@Entity
public class Usuario {
    @Id
    private String rut;
    private String nombre,email,contraseña,estado;


    @OneToMany(mappedBy = "usuario")
    private Set<Perfil> perfiles = new HashSet<>();
    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "usuario_persona")
    private Persona persona;
    

    public Usuario() {
        this.rut = "";
        this.nombre = "";
        this.email = "";
        this.contraseña = "";
        this.estado = "";
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public String getEmail() {
        return email;
    }


    public void setEmail(String email) {
        this.email = email;
    }


    public String getContraseña() {
        return contraseña;
    }


    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }



    public String getRut() {
        return rut;
    }



    public void setRut(String rut) {
        this.rut = rut;
    }


    public String getEstado() {
        return estado;
    }


    public void setEstado(String estado) {
        this.estado = estado;
    }





    public Set<Perfil> getPerfiles() {
        return perfiles;
    }


    public void setPerfiles(Set<Perfil> perfiles) {
        this.perfiles = perfiles;
    }


    public Persona getPersona() {
        return persona;
    }


    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    


    

   
    
    
    



}

