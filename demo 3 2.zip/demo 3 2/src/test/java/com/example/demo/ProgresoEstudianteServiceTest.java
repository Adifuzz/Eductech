package com.example.demo;

import com.example.demo.model.ProgresoEstudiante;

import com.example.demo.repository.ProgresoEstudianteRepository;

import com.example.demo.service.ProgresoEstudianteService;



import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.mockito.*;



import java.util.*;



import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;



class ProgresoEstudianteServiceTest {



  @Mock

  private ProgresoEstudianteRepository repo;



  @InjectMocks

  private ProgresoEstudianteService service;



  @BeforeEach

  void setUp() {

    MockitoAnnotations.openMocks(this);

  }



  // 1. Guardar un progreso correctamente

  @Test

  void testGuardar() {

    ProgresoEstudiante progreso = new ProgresoEstudiante();

    when(repo.save(progreso)).thenReturn(progreso);



    ProgresoEstudiante resultado = service.guardar(progreso);



    assertEquals(progreso, resultado);

    verify(repo, times(1)).save(progreso);

  }



  // 2. Buscar progreso por ID encontrado

  @Test

  void testBuscarPorId_Encontrado() {

    ProgresoEstudiante progreso = new ProgresoEstudiante();

    when(repo.findById(1)).thenReturn(Optional.of(progreso));



    Optional<ProgresoEstudiante> resultado = service.buscarPorId(1);



    assertTrue(resultado.isPresent());

    assertEquals(progreso, resultado.get());

  }


  //STANLEY
  // 3. Actualizar progreso cuando ya existe

  @Test

  void testActualizar_Existe() {

    ProgresoEstudiante original = new ProgresoEstudiante();

    original.setIdProgreso(1);

    ProgresoEstudiante nuevosDatos = new ProgresoEstudiante();

    nuevosDatos.setEstudianteRut("123");

    nuevosDatos.setCursoSigla("ABC");

    nuevosDatos.setPorcentajeAvance(90);

    nuevosDatos.setEstado("Activo");



    when(repo.findById(1)).thenReturn(Optional.of(original));

    when(repo.save(any())).thenReturn(original);



    ProgresoEstudiante resultado = service.actualizar(1, nuevosDatos);



    assertEquals("123", resultado.getEstudianteRut());

    verify(repo).findById(1);

    verify(repo).save(original);

  }

}
