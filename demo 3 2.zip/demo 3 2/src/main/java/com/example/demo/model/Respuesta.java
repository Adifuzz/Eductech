package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Respuesta {
    @Id
    private int isRespuesta;
    private String respuesta;


    @ManyToOne
    @JoinColumn(name = "mensaje_id")
    @JsonBackReference
    private Mensaje mensaje;

    //public Repuesta() {}

    public Respuesta() {
        this.isRespuesta = 0;
        this.respuesta = "";
    }


    public int getIsRespuesta() {
        return isRespuesta;
    }


    public void setIsRespuesta(int isRespuesta) {
        this.isRespuesta = isRespuesta;
    }


    public String getRespuesta() {
        return respuesta;
    }


    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }


    public Mensaje getMensaje() {
        return mensaje;
    }


    public void setMensaje(Mensaje mensaje) {
        this.mensaje = mensaje;
    }

    
    

    

}
