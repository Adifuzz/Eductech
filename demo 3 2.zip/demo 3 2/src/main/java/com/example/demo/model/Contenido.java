package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Contenido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idContenido;
    private String cursoSigla,tituloContenido,descripcionContenido,estadoContenido;


    public Contenido() {
        this.idContenido = 0;
        this.cursoSigla = "";
        this.tituloContenido = "";
        this.descripcionContenido = "";
        this.estadoContenido = ""; 
    }


    public int getIdContenido() {
        return idContenido;
    }


    public void setIdContenido(int idContenido) {
        this.idContenido = idContenido;
    }


    public String getCursoSigla() {
        return cursoSigla;
    }


    public void setCursoSigla(String cursoSigla) {
        this.cursoSigla = cursoSigla;
    }


    public String getTituloContenido() {
        return tituloContenido;
    }


    public void setTituloContenido(String tituloContenido) {
        this.tituloContenido = tituloContenido;
    }


    public String getDescripcionContenido() {
        return descripcionContenido;
    }


    public void setDescripcionContenido(String descripcionContenido) {
        this.descripcionContenido = descripcionContenido;
    }


    public String getEstadoContenido() {
        return estadoContenido;
    }


    public void setEstadoContenido(String estadoContenido) {
        this.estadoContenido = estadoContenido;
    } 

    

    

}

