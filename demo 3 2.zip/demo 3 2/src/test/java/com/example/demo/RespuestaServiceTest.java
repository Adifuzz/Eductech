package com.example.demo;

import com.example.demo.model.Respuesta;
import com.example.demo.repository.RespuestaRepository;
import com.example.demo.service.RepuestaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;


class RespuestaServiceTest {

    @Mock
    private RespuestaRepository repuestaRepository;

    @InjectMocks
    private RepuestaService repuestaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    //STANLEY
    @Test
    void testGetAllRepuestas() {
        Respuesta r1 = new Respuesta();
        Respuesta r2 = new Respuesta();

        when(repuestaRepository.findAll()).thenReturn(Arrays.asList(r1, r2));

        List<Respuesta> respuestas = repuestaService.getAllRepuestas();
        assertEquals(2, respuestas.size());
    }

    //STANLEY
    @Test
    void testDeleteRepuesta() {
        when(repuestaRepository.existsById(1)).thenReturn(true);
        doNothing().when(repuestaRepository).deleteById(1);

        boolean eliminado = repuestaService.deleteRepuesta(1);
        assertTrue(eliminado);
        verify(repuestaRepository, times(1)).deleteById(1);
    }

    
}
