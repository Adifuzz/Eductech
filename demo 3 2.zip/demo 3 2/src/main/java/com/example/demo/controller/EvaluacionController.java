package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Evaluacion;
import com.example.demo.service.EvaluacionService;

@RestController
@RequestMapping("evaluaciones")
@CrossOrigin(origins = "http://localhost:8080")
public class EvaluacionController {

    private final EvaluacionService evaluacionService;

    public EvaluacionController(EvaluacionService evaluacionService) {
        this.evaluacionService = evaluacionService;
    }

    // Crear evaluación
    @PostMapping
    public Evaluacion crearEvaluacion(@RequestBody Evaluacion evaluacion) {
        return evaluacionService.crearEvaluacion(evaluacion);
    }

    // Obtener evaluación por ID
    @GetMapping("/{id}")
    public Optional<Evaluacion> obtenerEvaluacionPorId(@PathVariable int id) {
        return evaluacionService.obtenerEvaluacionPorId(id);
    }

    // Listar todas las evaluaciones
    @GetMapping
    public List<Evaluacion> listarEvaluaciones() {
        return evaluacionService.listarEvaluaciones();
    }

    // Actualizar evaluación
    @PutMapping("/{id}")
    public Evaluacion actualizarEvaluacion(@PathVariable int id, @RequestBody Evaluacion evaluacion) {
        return evaluacionService.actualizarEvaluacion(id, evaluacion);
    }

    // Eliminar evaluación
    @DeleteMapping("/{id}")
    public void eliminarEvaluacion(@PathVariable int id) {
        evaluacionService.eliminarEvaluacion(id);
    }
}
