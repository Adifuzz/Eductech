package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Instructor;
import com.example.demo.service.InstructorService;

@RestController
@RequestMapping("/instructores")
@CrossOrigin (origins = "http://localhost:8080")
public class InstructorControlller {
    @Autowired
    private InstructorService instructorService;

    @PostMapping
    public String almacenarInstructor(@RequestBody Instructor instructor){
        return instructorService.almacenarInstructor(instructor);
    }

    @GetMapping
    public List<Instructor> listarInstructor(){
        return instructorService.listarInstructor();
    }

    @GetMapping("/{nombreCurso}")
    public List<Instructor> buscarInstructor(@PathVariable String nombreCurso){
        return instructorService.buscarInstructor(nombreCurso);
    }
}