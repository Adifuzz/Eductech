package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Evaluacion {
    @Id
    private int idEvalucion;
    private String nombre;


    public Evaluacion() {
        this.idEvalucion = 0;
        this.nombre = "";
    }


    public int getIdEvalucion() {
        return idEvalucion;
    }


    public void setIdEvalucion(int idEvalucion) {
        this.idEvalucion = idEvalucion;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    
    

}
