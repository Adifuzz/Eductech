package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Curso;



public interface CursoRepository extends JpaRepository<Curso,String> {
    Curso findByNombreCurso(String nombreCurso);

    List<Curso>findByNombreCursoContaining(String nombreCurso);

    List<Curso> findBySiglaStartingWith(String prefijo);

}
