package com.example.demo.dto;

public class PerfilUsuarioDTO { 
    private String tag;
    private String rut;


    public PerfilUsuarioDTO() {
        this.tag = "";
        this.rut = "";
    }


    public String getTag() {
        return tag;
    }


    public void setTag(String tag) {
        this.tag = tag;
    }


    public String getRut() {
        return rut;
    }


    public void setRut(String rut) {
        this.rut = rut;
    } 

    

    

}
