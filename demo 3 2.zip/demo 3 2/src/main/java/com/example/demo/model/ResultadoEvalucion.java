package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "RESULTADO_EVALUCION")
public class ResultadoEvalucion {   
    @Id
    private int idEvalucion;
    private double calificacion;


    public ResultadoEvalucion() {
        this.idEvalucion = 0;
        this.calificacion = 0.0; 

    }


    public int getIdEvalucion() {
        return idEvalucion;
    }


    public void setIdEvalucion(int idEvalucion) {
        this.idEvalucion = idEvalucion;
    }


    public double getCalificacion() {
        return calificacion;
    }


    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }  

    

    

}
