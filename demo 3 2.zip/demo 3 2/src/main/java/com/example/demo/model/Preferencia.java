package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Preferencia {
    @Id
    private int idPreferencia;
    private String descripcionPreferencia;


    public Preferencia() {
        this.idPreferencia = 0;
        this.descripcionPreferencia = "";
    }


    public int getIdPreferencia() {
        return idPreferencia;
    }


    public void setIdPreferencia(int idPreferencia) {
        this.idPreferencia = idPreferencia;
    }


    public String getDescripcionPreferencia() {
        return descripcionPreferencia;
    }


    public void setDescripcionPreferencia(String descripcionPreferencia) {
        this.descripcionPreferencia = descripcionPreferencia;
    } 

    

    

}
