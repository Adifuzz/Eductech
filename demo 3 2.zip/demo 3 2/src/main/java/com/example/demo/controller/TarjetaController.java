package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Tarjeta;
import com.example.demo.service.TarjetaService;

@RestController
@RequestMapping("/tarjetas")
@CrossOrigin (origins = "http://localhost:8080")
public class TarjetaController {
    @Autowired
    private TarjetaService tarjetaService;

    
    @PostMapping
    public ResponseEntity<?> guardarTarjeta(@RequestBody Tarjeta tarjeta) {
        try {
            Tarjeta tarjetaGuardada = tarjetaService.guardarTarjeta(tarjeta);
            return ResponseEntity.ok(tarjetaGuardada);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    
    @GetMapping
    public List<Tarjeta> listarTarjetas() {
        return tarjetaService.obtenerTodas();
    }

    
    @DeleteMapping("/{numeroTarjeta}")
    public ResponseEntity<String> eliminarTarjeta(@PathVariable String numeroTarjeta) {
        boolean eliminado = tarjetaService.eliminarTarjeta(numeroTarjeta);
        if (eliminado) {
            return ResponseEntity.ok("Tarjeta eliminada correctamente.");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
