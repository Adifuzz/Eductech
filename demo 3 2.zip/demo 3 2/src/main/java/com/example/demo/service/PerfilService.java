package com.example.demo.service;

import java.util.Collections;
import java.util.List;
import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.dto.PerfilUsuarioDTO;
import com.example.demo.model.Perfil;
import com.example.demo.model.Usuario;
import com.example.demo.repository.PerfilRepository;
import com.example.demo.repository.UsuarioRepository;

@Service
public class PerfilService {
    @Autowired
    private PerfilRepository perfilRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public String asignarPerfil(PerfilUsuarioDTO dto){
        if(!perfilRepository.existsById(dto.getTag())){
            return "El perfilingresado no existe";
        } else if(!usuarioRepository.existsById(dto.getRut())){
            return "El usuario no esta registrado";
        }else{
            Perfil perfil = perfilRepository.findById(dto.getTag()).get();
            Usuario usuario = usuarioRepository.findById(dto.getRut()).get();

            perfil.setUsuario(usuario);
            perfilRepository.save(perfil);

            return "Perfil "+ perfil.getTag()+" asiganado a Usuario "
                +usuario.getNombre()+" correctamente";


        }
        
    }

    


    public Set<Perfil> obtenerPerfilesDeUsuario(String rut) {
        Usuario usuario = usuarioRepository.findById(rut).orElse(null);

        if (usuario != null) {
            return usuario.getPerfiles();
        }

        return Collections.emptySet();
    }

 
    public boolean tienePermiso(String rut, String permiso) {
        Usuario usuario = usuarioRepository.findById(rut).orElse(null);

        if (usuario == null) {
            return false;
        }

        for (Perfil perfil : usuario.getPerfiles()) {
            if (permiso.equals("adminSistema") && perfil.isAdminSistema()) return true;
            if (permiso.equals("adminCurso") && perfil.isAdminCurso()) return true;
            if (permiso.equals("alumno") && perfil.isAlumno()) return true;
        }

        return false;
    }

    // Listar todos los perfiles
    public List<Perfil> listarPerfi() {
        return perfilRepository.findAll();
    }

    public String almacenarPerfil(Perfil perfil) {
        if (perfilRepository.existsById(perfil.getTag())) {
            return "Perfil " + perfil.getTag() + " ya se encuentra registrado";
        } else {
            perfilRepository.save(perfil);
            return "Perfil " + perfil.getTag() + " almacenado correctamente";
        }
    }

    
}
