package com.example.demo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Mensaje {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cursoSigla;
    private String emisor;
    private String contenido;
    @ManyToOne
    @JoinColumn(name = "rut_instructor")
    @JsonBackReference
    private Instructor instructor;

    @OneToMany(mappedBy = "mensaje", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Respuesta> repuestas;

    public Mensaje() {}

    

    public Mensaje(String cursoSigla, String emisor, String contenido) {
        this.cursoSigla = cursoSigla;
        this.emisor = emisor;
        this.contenido = contenido;
    }

    public Long getId() {
        return id;
    }

    public String getCursoSigla() {
        return cursoSigla;
    }

    public void setCursoSigla(String cursoSigla) {
        this.cursoSigla = cursoSigla;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }



    public void setId(Long id) {
        this.id = id;
    }



    public Instructor getInstructor() {
        return instructor;
    }



    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }



    public List<Respuesta> getRepuestas() {
        return repuestas;
    }



    public void setRepuestas(List<Respuesta> repuestas) {
        this.repuestas = repuestas;
    }

    
}