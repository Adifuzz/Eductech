package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.model.ProgresoEstudiante;
import com.example.demo.repository.ProgresoEstudianteRepository;

@Service
public class ProgresoEstudianteService {

    private final ProgresoEstudianteRepository repo;

    public ProgresoEstudianteService(ProgresoEstudianteRepository repo) {
        this.repo = repo;
    }

    public ProgresoEstudiante guardar(ProgresoEstudiante progreso) {
        return repo.save(progreso);
    }

    public List<ProgresoEstudiante> listar() {
        return repo.findAll();
    }

    public Optional<ProgresoEstudiante> buscarPorId(int id) {
        return repo.findById(id);
    }

    public void eliminar(int id) {
        repo.deleteById(id);
    }

    public ProgresoEstudiante actualizar(int id, ProgresoEstudiante datos) {
        return repo.findById(id).map(p -> {
            p.setEstudianteRut(datos.getEstudianteRut());
            p.setCursoSigla(datos.getCursoSigla());
            p.setPorcentajeAvance(datos.getPorcentajeAvance());
            p.setEstado(datos.getEstado());
            return repo.save(p);
        }).orElseGet(() -> {
            datos.setIdProgreso(id);
            return repo.save(datos);
        });
    }
}
