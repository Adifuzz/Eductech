package com.example.demo.dto;

import java.util.List;

public class UsuarioDTO {
    private String rut;
    private String nombre;
    private String email;
    private String estado;
    private List<String> perfiles;

    public UsuarioDTO() {
       
    }

    public UsuarioDTO(String rut, String nombre, String email, String estado, List<String> perfiles) {
        this.rut = rut;
        this.nombre = nombre;
        this.email = email;
        this.estado = estado;
        this.perfiles = perfiles;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public List<String> getPerfiles() {
        return perfiles;
    }

    public void setPerfiles(List<String> perfiles) {
        this.perfiles = perfiles;
    }

    

    
}
