package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CursoInstructorDTO;
import com.example.demo.model.Curso;
import com.example.demo.model.Instructor;
import com.example.demo.repository.CursoRepository;
import com.example.demo.repository.InstructorRepository;

@Service
public class CursoService {
    @Autowired
    private CursoRepository cursoRepository; 
    @Autowired
    private InstructorRepository instructorRepository;
    @Autowired
    private PerfilService perfilService;

    public String almacenarCurso(Curso curso,String rut){
        if (!perfilService.tienePermiso(rut, "adminCurso")) {
            return "Error: No tienes permiso para crear curso.";
        }
        String prefijo = curso.getSigla().toUpperCase(); 
        
        
        List<Curso> cursosConPrefijo = cursoRepository.findBySiglaStartingWith(prefijo);
        int numero = cursosConPrefijo.size() + 1;
    
        String nuevaSigla = prefijo + numero;
        curso.setSigla(nuevaSigla);
    
        cursoRepository.save(curso);
        return "Curso almacenado con sigla: " + nuevaSigla;
    }

    public List<Curso> listarCurso(){
        return cursoRepository.findAll();
    }

    public List<Curso> buscarCurso(String nombreCurso){
        return cursoRepository.findByNombreCursoContaining(nombreCurso);
    } 

    public String asignarCurso(String sigla, String rutInstructor){
        if(!cursoRepository.existsById(sigla)){
            return "El curso ingresado no existe";
        } else if(!instructorRepository.existsById(rutInstructor)){
            return "El instructor no esta registrado";
        }else{
            Curso curso = cursoRepository.findById(sigla).get();
            Instructor instructor = instructorRepository.findById(rutInstructor).get();

            curso.setInstructor(instructor);
            cursoRepository.save(curso);

            return "Curso "+ curso.getNombreCurso()+" asiganado a instructor "
                +instructor.getNombreInstructor()+" correctamente";


        }
        
    }

    public String asignarCurso(CursoInstructorDTO dto,String rut){
        if (!perfilService.tienePermiso(rut, "adminCurso")) {
            return "Error: No tienes permiso para asignar cursos.";
        }
    
        if(!cursoRepository.existsById(dto.getSigla())){
            return "El curso ingresado no existe";
        } else if(!instructorRepository.existsById(dto.getRutInstructor())){
            return "El instructor no esta registrado";
        }else{
            Curso curso = cursoRepository.findById(dto.getSigla()).get();
            Instructor instructor = instructorRepository.findById(dto.getRutInstructor()).get();

            curso.setInstructor(instructor);
            cursoRepository.save(curso);

            return "Curso "+ curso.getNombreCurso()+" asiganado a instructor "
                +instructor.getNombreInstructor()+" correctamente";


        }        

    } 

    

    public String generarSigla(String nombreCurso) {
        String prefijo = nombreCurso.trim().substring(0, 2).toUpperCase();
    
        // Buscar cursos con el mismo prefijo
        List<Curso> cursosConPrefijo = cursoRepository.findBySiglaStartingWith(prefijo);
    
        int numero = cursosConPrefijo.size() + 1;
    
        return prefijo + numero;
    }

    
}
