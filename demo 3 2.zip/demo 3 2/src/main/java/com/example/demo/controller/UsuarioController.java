package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UsuarioDTO;
import com.example.demo.model.Usuario;
//import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.UsuarioSrevice;

@RestController
@RequestMapping("/usuarios")
@CrossOrigin (origins = "http://localhost:8080")
public class UsuarioController {

    @Autowired
    private UsuarioSrevice usuarioService;
    //@Autowired
    //private UsuarioRepository usuarioRepository;

    
    @PostMapping
    public String almacenarUsuario(@RequestBody Usuario usuario){
        return usuarioService.almacenarUsuario(usuario);
    }
    
    

    @GetMapping
    public List<UsuarioDTO> obtenerUsuarios() {
        return usuarioService.listarUsuariosDTO();
    }

    @GetMapping("/{nombre}")
    public List<Usuario> buscarUsuario(@PathVariable String nombre) {
        return usuarioService.buscarUsuario(nombre);
    }

    @PutMapping("/{rut}")
    public ResponseEntity<Usuario> actualizarUsuario(@PathVariable String rut, @RequestBody Usuario usuarioActualizado) {
        return usuarioService.actualizarUsuario(rut, usuarioActualizado)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{rut}")
    public ResponseEntity<Void> eliminarUsuario(@PathVariable String rut) {
        if (usuarioService.eliminarUsuario(rut)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}

