package com.example.demo;

import com.example.demo.model.Persona;
import com.example.demo.repository.PersonaRepository;
import com.example.demo.service.PersonaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
//import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PersonaServiceTest {

    @Mock
    private PersonaRepository personaRepository;

    @InjectMocks
    private PersonaService personaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGuardarPersona() {
        Persona persona = new Persona();
        persona.setRutPersona("12345678-9");

        when(personaRepository.save(persona)).thenReturn(persona);

        Persona resultado = personaService.guardarPersona(persona);

        assertNotNull(resultado);
        assertEquals("12345678-9", resultado.getRutPersona());
        verify(personaRepository, times(1)).save(persona);
    }

    @Test
    void testObtenerPersona_Encontrada() {
        Persona persona = new Persona();
        persona.setRutPersona("12345678-9");

        when(personaRepository.findByRutPersona("12345678-9")).thenReturn(persona);

        Persona resultado = personaService.obtenerPersona("12345678-9");

        assertNotNull(resultado);
        assertEquals("12345678-9", resultado.getRutPersona());
        verify(personaRepository, times(1)).findByRutPersona("12345678-9");
    }

    @Test
    void testObtenerPersona_NoEncontrada() {
        when(personaRepository.findByRutPersona("99999999-9")).thenReturn(null);

        Persona resultado = personaService.obtenerPersona("99999999-9");

        assertNull(resultado);
        verify(personaRepository, times(1)).findByRutPersona("99999999-9");
    }

    @Test
    void testListarPersonas() {
        Persona persona1 = new Persona();
        Persona persona2 = new Persona();
        List<Persona> personas = Arrays.asList(persona1, persona2);

        when(personaRepository.findAll()).thenReturn(personas);

        List<Persona> resultado = personaService.listarPersonas();

        assertEquals(2, resultado.size());
        verify(personaRepository, times(1)).findAll();
    }

    @Test
    void testEliminarPersona_Existente() {
        when(personaRepository.existsById(1)).thenReturn(true);
        doNothing().when(personaRepository).deleteById(1);

        boolean resultado = personaService.eliminarPersona(1);

        assertTrue(resultado);
        verify(personaRepository, times(1)).deleteById(1);
    }

    @Test
    void testEliminarPersona_NoExistente() {
        when(personaRepository.existsById(999)).thenReturn(false);

        boolean resultado = personaService.eliminarPersona(999);

        assertFalse(resultado);
        verify(personaRepository, never()).deleteById(anyInt());
    }

    @Test
    void testActualizarPersona_Existente() {
        Persona persona = new Persona();
        persona.setIdPersona(1);
        persona.setRutPersona("12345678-9");

        when(personaRepository.existsById(1)).thenReturn(true);
        when(personaRepository.save(persona)).thenReturn(persona);

        Persona resultado = personaService.actualizarPersona(persona);

        assertNotNull(resultado);
        assertEquals("12345678-9", resultado.getRutPersona());
        verify(personaRepository, times(1)).save(persona);
    }

    @Test
    void testActualizarPersona_NoExistente() {
        Persona persona = new Persona();
        persona.setIdPersona(999);

        when(personaRepository.existsById(999)).thenReturn(false);

        Persona resultado = personaService.actualizarPersona(persona);

        assertNull(resultado);
        verify(personaRepository, never()).save(any());
    }
}
