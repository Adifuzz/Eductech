package com.example.demo.controller;





import java.util.List;

import java.util.Optional;



import org.springframework.web.bind.annotation.*;

import com.example.demo.model.ProgresoEstudiante;

import com.example.demo.service.ProgresoEstudianteService;



@RestController

@RequestMapping("progresos")

@CrossOrigin(origins = "http://localhost:8080")

public class ProgresoEstudianteController {



  private final ProgresoEstudianteService servicio;



  public ProgresoEstudianteController(ProgresoEstudianteService servicio) {
    this.servicio = servicio;

  }



  @PostMapping
  public ProgresoEstudiante crear(@RequestBody ProgresoEstudiante progreso) {
    return servicio.guardar(progreso);

  }



  @GetMapping
  public List<ProgresoEstudiante> listar() {
    return servicio.listar();

  }



  @GetMapping("/{id}")
  public Optional<ProgresoEstudiante> buscar(@PathVariable int id) {

    return servicio.buscarPorId(id);

  }



  @PutMapping("/{id}")
  public ProgresoEstudiante actualizar(@PathVariable int id, @RequestBody ProgresoEstudiante progreso) {

    return servicio.actualizar(id, progreso);

  }



  @DeleteMapping("/{id}")
  public void eliminar(@PathVariable int id) {
    servicio.eliminar(id);

  }

}