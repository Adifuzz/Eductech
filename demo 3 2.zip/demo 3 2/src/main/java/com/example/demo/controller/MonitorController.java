package com.example.demo.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repository.CursoRepository;
import com.example.demo.repository.UsuarioRepository;
import com.example.demo.service.PerfilService;

@RestController
@RequestMapping("/monitor")
@CrossOrigin (origins = "http://localhost:8080")
public class MonitorController {
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private PerfilService perfilService;

    @GetMapping("/{rut}")
    public ResponseEntity<?> obtenerEstadoSistema(@PathVariable String rut) {
        // Validar si tiene el permiso adminSistema
        if (!perfilService.tienePermiso(rut, "adminSistema")) {
            return ResponseEntity.status(403).body("Acceso denegado: no tiene permiso adminSistema");
        }

        Map<String, Object> estado = new HashMap<>();
        estado.put("estado", "OK");
        estado.put("fecha", LocalDateTime.now());
        estado.put("usuarios_totales", usuarioRepository.count());
        estado.put("cursos_totales", cursoRepository.count());
        estado.put("mensaje", "Sistema funcionando correctamente");

        return ResponseEntity.ok(estado);
    }

    

}
