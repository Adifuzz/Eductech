package com.example.demo.service;

import com.example.demo.model.Respuesta;
import com.example.demo.repository.RespuestaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RepuestaService {

    @Autowired
    private RespuestaRepository repuestaRepository;

    public List<Respuesta> getAllRepuestas() {
        return repuestaRepository.findAll();
    }

    public Optional<Respuesta> getRepuestaById(int id) {
        return repuestaRepository.findById(id);
    }

    public Respuesta createRepuesta(Respuesta repuesta) {
        return repuestaRepository.save(repuesta);
    }

    public Respuesta updateRepuesta(int id, Respuesta updatedRepuesta) {
        return repuestaRepository.findById(id).map(repuesta -> {
            repuesta.setRespuesta(updatedRepuesta.getRespuesta());
            return repuestaRepository.save(repuesta);
        }).orElse(null);
    }

    public boolean deleteRepuesta(int id) {
        if (repuestaRepository.existsById(id)) {
            repuestaRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
