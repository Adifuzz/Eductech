package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ProgresoEstudiante;

public interface ProgresoEstudianteRepository extends JpaRepository<ProgresoEstudiante,Integer> {

}
